from flask import Flask, render_template, redirect, request

app = Flask(__name__)

full_stars = 0
empty_stars = 10
half_stars = 0
rating = 0


@app.route('/DrawRating')
def draw_rating():
    # TODO
    return calc_rating(rating)


@app.route('/')
def index():
    return render_template('index.html',
                           rating=rating,
                           full_stars=full_stars,
                           empty_stars=empty_stars,
                           half_stars=half_stars)


def calc_rating(rating):
    # TODO
    return redirect('/')


if __name__ == '__main__':
    app.run()

